DateName=`date +'%Y%m%d'`
tar cvf DoMenu$DateName.tar  ./*.c ./makefile ./pkg.sh ./etc/menu.txt README.txt
gzip -9  DoMenu$DateName.tar 
