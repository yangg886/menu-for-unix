/*****************************************************  
�ó���Ϊ��ִ��ͳһ�˵����   yangg at  2012-5-1 

���룺 ./main.c ./browfunc.c ./work.c ./makefile 

���룺$  make -f makefile  

�轨���� ./bin ./tmp Ŀ¼���� 

ִ�� �� $ main 

*************************************************/
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/termio.h>
#include <curses.h>
#include <string.h>
#include <signal.h>
#include <sys/ipc.h>
#include <math.h>

#define TIMEOUT 120    /**  ��ʱʱ��    60 ���� ***/

/* ���̰������� */
#define KBD_EXT_BASE	0x0100 

/* IBM���̰������� */
#define KBD_IBM_BASE	KBD_EXT_BASE		/* ESC������չ������ֵ */

#define KBD_UP			(KBD_IBM_BASE+'A')
#define KBD_DOWN		(KBD_IBM_BASE+'B')
#define KBD_RIGHT		(KBD_IBM_BASE+'C')
#define KBD_LEFT		(KBD_IBM_BASE+'D')

#define KBD_END			(KBD_IBM_BASE+'F')
#define KBD_PGDN		(KBD_IBM_BASE+'G')
#define KBD_HOME		(KBD_IBM_BASE+'H')
#define KBD_PGUP		(KBD_IBM_BASE+'I')


/* ���ⰴ������ */
#define KBD_ESC			0x1B
#define KBD_DEL			0x7F
#define KBD_BS			0x08
#define KBD_TAB			0x09
#define KBD_CR			0x0D
#define KBD_LF			0x0A
#define KBD_ENTER		KBD_LF
#define KBD_RETURN		KBD_LF
#define KBD_SPACE		0x20
#define KBD_PAUSE		0x13

int MaxRow = 1;
int CurCol = 1;
int CurRow = 1;
int MaxLen = 0;

WINDOW *win;



int row_star , row_end , col_star , col_end ;

/*************** menu **************/
/**  menu_num �� menu_ROW ; menu_disp ; menu_operation; menu_pre ***/

struct menu { 
	int  menu_id ;
	int menu_before; 
	int modify ;
	char disp[41];   /********* display menu ***/
	char oper[25];  /***  run command  ***/
	int ret ;      /***  result  ***/
	struct menu *Next ;
	}	;

struct menu *pmenu ;
struct menu  *pHead , *pCurrent , *pThis ;

/*************** menu  end **************/

int main(int argc, char *argv[])
{


	if (  argc  > 1 )
	{
	printf("\n\n\t\t  ���г���[%s]  ����Ҫ��   \n ",argv[0] ) ;
	exit(-1);
	}

	win =  initscr();
	noecho();

	wclear(win); 

	wrefresh(win);

	if ( Init_Screen() )
	{
	exit(-1);
	}

	Run_Menu();
	  
	endwin();

	exit(0);
}
            
/****            ***/
int Init_Screen()
{

FILE *fp;
int i=0  ;


if (( fp = fopen("./etc/MENU.SCR" , "rb"))==NULL )
	{
	printf("\n\n\t\t  �� MENU.SCR��   \n ") ;
	return(-1);
	}

	while(1) {	

	(struct nemu  * ) pCurrent =  malloc ( sizeof ( struct menu ));  
	if (  pCurrent == NULL )
	{
	printf("\n[%s][%d]\t\t  ���г��� malloc��   \n ",__FILE__,__LINE__) ;
	return(-1);
	}
 
	memset ((struct menu *)pCurrent, 0x0, sizeof ( struct menu)); 
	if ( fread ( pCurrent ,1, sizeof(struct menu ), fp ) < 40  )
	{
	printf("\n[%s][%d]\t  debug   \n " , __FILE__, __LINE__ ) ;
	free( pCurrent );
 	break ;
	}
 	if ( i == 0 )
	{
	pHead = pCurrent ;
	pThis = pCurrent ;
	}
	else
	{
	pThis->Next = pCurrent ;
	pThis = pCurrent ;
	}
	pCurrent->disp[40]=0x0;
	pCurrent->oper[24]=0x0;
	i ++ ;
/**
 	if ( i > 4 ) break ; 		
**/	
 	}   /******************while (1) *************/
	
	pThis = pHead ;

	MaxRow =  i  ; 


	/**
	printf("\n[%s][%d]\t  debug   \n " , __FILE__, __LINE__ ) ;
	**/

	(struct menu  *) pmenu =  malloc ( sizeof ( struct menu ) * MaxRow  ) ;  


	if (  pmenu == NULL )
	{
	printf("\n[%s][%d]\t\t  ���г��� malloc��   \n ",__FILE__,__LINE__) ;
	Free_Menu();
	return(-1);
	}

	memset ((struct menu *)  pmenu , 0x0, sizeof ( struct menu ) * MaxRow);
	i=0;
  	while ( pThis !=NULL )
	{
	memcpy( &pmenu[i],pThis,sizeof(struct menu )) ;
	i++ ;
	pThis = pThis->Next ;

	}	


row_star = 1 ;
col_star = 1 ;
row_end  = 20 ;    
col_end  = 60 ;
CurRow  = 1 ;
 	fclose(fp);

return(0) ;	


}

int Init_Screen_bak()
{
	MaxRow =  10 ;   /*****************���� �޸� �˵���������  ***/

	(char *) pmenu =  malloc ( sizeof ( struct menu ) * MaxRow  ) ;  

	if (  pmenu == NULL )
	{
	printf("\n\n\t\t  ���г��� malloc��   \n ") ;
	return(-1);
	}

	memset ((struct menu *)  pmenu , 0x0, sizeof ( struct menu ) * MaxRow);
	
 	strncpy ( pmenu[0].disp , "�˵�1 hostname " , 25 );   /*****�˵������޸�***/
 	strncpy ( pmenu[1].disp , "�˵�2 rm ./tmp/*.log " , 25 ); 
 	strncpy ( pmenu[2].disp , "�˵�3 ls  " , 10 ); 
 	strncpy ( pmenu[3].disp , "�˵�4 date" , 10 ); 
 	strncpy ( pmenu[4].disp , "�˵�5 time  " , 10 ); 
 	strncpy ( pmenu[5].disp , "�˵� pwd " , 10 ); 
 	strncpy ( pmenu[6].disp , "�˵�7 df   " , 10 ); 
 	strncpy ( pmenu[7].disp , "�˵�8   " , 10 ); 
 	strncpy ( pmenu[8].disp , "�˵�9   " , 10 ); 
 	strncpy ( pmenu[9].disp , "work ./tmp/run.log " , 25 ); 
 
 	strncpy ( pmenu[0].oper , "hostname " , 10 );            
 	strncpy ( pmenu[1].oper , "rm ./tmp/*.log; " , 20 ); 
 	strncpy ( pmenu[2].oper , "ls -l " , 10 ); 
 	strncpy ( pmenu[3].oper , "date " , 10 ); 
 	strncpy ( pmenu[4].oper , "time  " , 10 ); 
 	strncpy ( pmenu[5].oper , "pwd  " , 10 ); 
 	strncpy ( pmenu[6].oper , " df -k  " , 10 ); 
 	strncpy ( pmenu[7].oper , "�˵�7   " , 10 ); 
 	strncpy ( pmenu[8].oper , "�˵�9   " , 10 ); 
 	strncpy ( pmenu[9].oper , "work ./tmp/run.log;" , 20 );   /**********�޸����***/

 	pmenu[0].ret = 1 ;  
 	pmenu[1].ret = 1 ;  
 	pmenu[2].ret = 1 ;  
 	pmenu[3].ret = 1 ;  
 	pmenu[4].ret = 1 ;  
 	pmenu[5].ret = 1 ;  
 	pmenu[6].ret = 1 ;  
 	pmenu[7].ret = 1 ;  
 	pmenu[8].ret = 1 ;  
 	pmenu[9].ret = 1 ;  
 
row_star = 1 ;
col_star = 1 ;
row_end  = 20 ;    
col_end  = 50 ;
CurRow  = 1 ;

return(0) ;	


}

void set_termstock()
{
	struct	termio	stTermio;

	ioctl( 0, TCGETA, &stTermio );

	stTermio.c_iflag |= IXON | IXOFF;
	stTermio.c_lflag &= ~(ECHO);

	/*ioctl( 0, TCSETAW, &stTermio );
	*/
	ioctl( 0, TCSETAF, &stTermio );

	return;
}




void sigproc ( int sig )
{
 PrcsErr() ;
}
/********************************************************************/
/* Run_Menu - ��ʾ�ļ�����                                          */
/********************************************************************/
int Run_Menu()
{
	int key;
	int ret;
	char  Cmd[200];

	signal ( SIGALRM , sigproc ) ;

	do {
		alarm(TIMEOUT); 

		clrbuf();		/* */

		Disp_Menu();		/* ��ʾMenu���� */

		key = prcsinp();
	
		if ( key < 0  )
		return(-1);
		
		if ( key > 0  && key < MaxRow + 1 ) 	
			{
			ret = 0 ;

	mvprintw(row_end + 1 ,col_star + 34 ,"[ȷ��ִ��yY]" );
	noecho();
		wmove(win,row_end +1 ,col_star + 46 );
	wrefresh(win);
		key = scr_wgetch(win);  
	if ( key != 'y' && key != 'Y' )
		continue;

	if (  pmenu[CurRow-1].modify ==0 )
		continue;

			memset ( Cmd, 0x0 , strlen ( Cmd )) ; 
			sprintf (Cmd, " %s 2>./tmp/err.log 1>./tmp/run.log " , pmenu[CurRow -1].oper ); 
			ret = system ( Cmd ) ;

			if ( ret == 0 )
			{
			 pmenu[CurRow -1].ret = 0  ;
				system( " work ./tmp/run.log " ) ;
			}
			else 
				{
			 pmenu[CurRow -1].ret = -1  ;
				system( " work ./tmp/err.log " ) ;
				}

			}
		       
		} while (1);
	return(0);
}


/********************************************************************/
/* - ����Ļ                                           */
/********************************************************************/
int clrbuf()
{
	wclear(win); 
	return(0);
}

/********************************************************************/
/*  - ��ʾ����������                                          */
/********************************************************************/
Disp_Menu()
{
	int i ;

	char  space79[80] ;

	memset( space79 , ' ' , strlen(space79) ) ;

	space79[col_end - col_star - 1 ]='\0' ;

	scr_wbox(win,row_star,col_star,row_end,col_end ) ;

	for ( i = 1 ; i< (MaxRow + 1) ; i++ )
	{
		if (pmenu[i-1].ret == 1 )
			mvprintw(row_star + i ,col_star + 50 ,"δִ��  ");
		else  if  ( pmenu[i-1].ret < 0 )
			mvprintw(row_star + i ,col_star + 50 ,"ִ��ʧ��");
		      else 
			mvprintw(row_star + i ,col_star + 50 ,"ִ�гɹ�");
                if(pmenu[i-1].modify ==0)	
			mvprintw(row_star + i ,col_star + 50 ,"��������");
		
		
		if ( CurRow == i )
		{
		wattrset ( win , A_REVERSE ) ;
		mvprintw(row_star + i ,col_star + 1 ,"%s",space79);
		mvprintw(row_star + i ,col_star + 1 ," %s ",pmenu[i-1].disp);
		wattrset ( win , A_NORMAL ) ;
		}
		else
	 	{
		mvprintw(row_star + i ,col_star + 1 ,"%s",space79);
		mvprintw(row_star + i ,col_star + 1 ," %s ",pmenu[i-1].disp);
		}	
	}
	mvprintw(row_end + 1 ,col_star + 2 ,"��ѡ��˵����س�ִ��Qq�˳�!" );
	wrefresh(win);

	return 0;
}

/********************************************************************/
/*	prcsinp - ���봦��                                              */
/********************************************************************/
int prcsinp()
{
	int inp;

		wmove(win, row_star + CurRow ,2);
		inp = scr_wgetch(win);  
		switch(inp)
		{
			case 'q':    /**  exit ***/
			case 'Q': 
			case KBD_ESC: 
				return(-1);
			case 'k':    /* ���� */
			case 'K':
			case KBD_UP:
			case KBD_PGUP:
			case KBD_LEFT:
				CurRow -- ;
				break;
			case 'j':    /* ���� */
			case 'J':
			case KBD_DOWN:
			case KBD_PGDN:
			case KBD_RIGHT:
				CurRow ++ ;
				break;
			case 't':    /* First */
			case 'T':
			case KBD_HOME:
				CurRow = 1 ;
				break ;
			case 'b':    /* END  */
			case 'B':
			case KBD_END:
				CurRow = MaxRow     ;
				break ;
			case KBD_ENTER: 
			    	return(CurRow);
			default	: 
			    	return(0);
		}
	if ( CurRow < 1 )
	     CurRow = 1 ;
	if ( CurRow > MaxRow )
	     CurRow = MaxRow ;
	return ( 0 ) ;
}

/********************************************************************/
/********************************************************************/
/*  filbuf - ��д������                                             */
/********************************************************************/
filbuf()
{
	return 0;
}
/********************************************************************/
/* PrcsErr - ������������                                         */
/********************************************************************/
int PrcsErr()
{

	endwin();
	return(-1);
}
int Free_Menu()
{

pThis = pHead ;

while ( pHead != NULL )
{
	pThis  = pThis->Next ;
	free(pHead);
	pHead = pThis ;
}
return(0);
}
