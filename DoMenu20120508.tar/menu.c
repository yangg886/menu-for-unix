/*****************************************************  
�ó���Ϊ��ִ��ͳһ�˵����   yangg at  2012-5-8 

���룺 ./

���룺$  make -f makefile  

�轨���� ./bin ./tmp Ŀ¼���� 

ִ�� �� $ main 

input :  menu.txt  ; 
output : MENU.SCR ;
*************************************************/
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/termio.h>
#include <curses.h>
#include <string.h>
#include <signal.h>
#include <sys/ipc.h>
#include <math.h>

   


/*************** menu **************/
/**  menu_num �� menu_ROW ; menu_disp ; menu_operation; menu_pre ***/

struct menu { 
	int  menu_id ;
	int menu_before;
	int modify; 
	char disp[41];   /********* display menu ***/
	char oper[25];  /***  run command  ***/
	int ret ;      /***  result  ***/
	struct  menu *Next ;
	}	;

struct menu *pmenu , *pHead , *pCurrent;

/*************** menu  end **************/

FILE  *fp1 , *fp2 ;


int main(int argc, char *argv[])
{
	

	if (argc != 3 )
	{
 		printf ( "\n ���� ERROR :  $ %s  menu.txt MENU.SCR  \n " , argv[0]) ;
		  exit ( -1 ) ;
	}

/****
	fp1 = fopen (argv[1], "rb") ;
***/
	fp1 = fopen ("./etc/menu.txt", "rb") ;
 	if (  fp1 == NULL )
		{
		  printf( " \n open  read  error  in [%s] \n" , argv[1] ) ;
		  exit ( -1 ) ;
	 	}

/********
	fp2 = fopen (argv[2], "wb");
******/
	fp2 = fopen ("./etc/MENU.SCR", "wb");
 	if (  fp2 == NULL )
		{
		  printf( " \n open  write   error  in [%s] \n " , argv[2] ) ;
		  fclose ( fp1 ) ;
		  exit ( -1 ) ;
	 	}

	if ( Read_Form() )
	{
	printf ( "\n error  in read  menu config  \n" ) ;
	fclose(fp1);
	fclose(fp2);
	exit(-1);
	}

	if ( Creat_Menu() )
	{
	printf ( "\n error  in creat MENU.SRC \n" ) ;
	fclose(fp1);
	fclose(fp2);
	Free_Menu();
	exit(-1);
	}

	Free_Menu();
	fclose(fp1);
	fclose(fp2);
printf ( "\n  \t\t  success to creat ./etc/MENU.SRC          OK !! \n" ) ;
exit(0);
}

int Read_Form()
{

int  i = 0 ;
char  stringbuff[100]; 
char  str2[50]; 

memset ( stringbuff  , 0x0  , sizeof ( stringbuff ));
	

	pHead = NULL ;

	while (1) 
 	{
 		if ( fgets( stringbuff , 200,fp1 ) == NULL  )
		break ;
		
		if ( stringbuff[0] == '#' )
		continue;

		if ( strlen ( stringbuff ) < 40 ) 
		continue ;
		
		
	(char *) pmenu =  malloc ( sizeof ( struct menu )  ) ;  

	memset ( str2 , 0x0 , sizeof( str2));
 	getstring ( stringbuff, str2 ,   1 ) ;
	if ( str2[0] == 0x0 )
	{
	free ( pmenu ) ;
	break ;
	}
	pmenu->menu_id = atoi(str2);

	memset ( str2 , 0x0 , sizeof ( str2));
 	getstring ( stringbuff , str2 ,   2 ) ;
	if ( str2[0] == 0x0 )
	{
	free ( pmenu ) ;
	break ;
	}
	pmenu->menu_before = atoi(str2);

	memset ( str2 , 0x0 , sizeof ( str2));
 	getstring ( stringbuff , str2 ,   3 ) ;
	if ( str2[0] == 0x0 )
	{
	free ( pmenu ) ;
	break ;
	}
	pmenu->modify = atoi(str2);

	memset ( str2 , 0x0 , sizeof ( str2));
 	getstring ( stringbuff , str2 ,   4 ) ;
	if ( str2[0] == 0x0 )
	{
	free ( pmenu ) ;
	break ;
	}
	sprintf(pmenu->disp , "%s",str2 );
  
	memset ( str2 , 0x0 , sizeof ( str2));
 	getstring ( stringbuff , str2 ,   5 ) ;
	if ( str2[0] == 0x0 )
	{
	free ( pmenu ) ;
	break ;
	}
	sprintf(pmenu->oper , "%24s",str2 );

	memset ( str2 , 0x0 , sizeof ( str2));
 	getstring ( stringbuff , str2 ,   6 ) ;
	if ( str2[0] == 0x0 )
	{
	free ( pmenu ) ;
	break ;
	}
	pmenu->ret = atoi(str2);

	pmenu->Next = NULL ;

	if ( i == 0  ) 
	{
	pHead = pmenu ;
	pCurrent = pmenu ;
	}
	else
	{
	pCurrent->Next = pmenu ;
	pCurrent = pmenu ;
	}
	
	i++ ;

	        	
  	}     /*********  while(1)  **/	

	if ( pHead == NULL )
	return(-1);
	else
	return(0);
}
            
int  Creat_Menu()
{

pCurrent = pHead ;
while ( pCurrent != NULL )
{
if ( fwrite ( pCurrent , 1 , sizeof( struct menu )  , fp2 ) < 0 )
   return (-1);
pCurrent = pCurrent->Next ;
}
return(0);
}


int Free_Menu()
{

pCurrent = pHead ;

while ( pHead != NULL )
{
	pCurrent  = pCurrent->Next ;
	free(pHead);
	pHead = pCurrent ;
}

return(0);
}

int getstring( char * strbuff_in , char * strbuff_out , int number )
{
char CH = '@' ;
char strbuff_tmp[100] ;
int  i , j , k ;

memset (  strbuff_out , 0x0 , sizeof ( strbuff_out ));
memset (  strbuff_tmp , 0x0 , sizeof ( strbuff_tmp ));

if ( strlen ( strbuff_in ) <  40 )
{
return(-1);
}

strncpy ( strbuff_tmp , strbuff_in , 100 ) ;
i = number ;
j=k=0;

while ( i > -1   ) 
{
 
if ( strbuff_tmp[j] == CH )
{
 	
 if ( i == 1 ) 
	{
	k = j  + 1 ;
 	strbuff_tmp[j]=0x0 ;
	}
 if ( i == 0 ) 
	{
 	strbuff_tmp[j]=0x0 ;
	}
  i-- ;

}
	j++ ;
 if ( sizeof ( strbuff_tmp ) < j )
  break ;
}

strcpy ( strbuff_out , strbuff_tmp + k );
/******
printf("\n\n \t\t [%s]\n",strbuff_out ) ;
***/
return(0);

}

