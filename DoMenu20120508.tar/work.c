#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/termio.h>
#include <curses.h>
#include <string.h>
#include <signal.h>
#include <sys/ipc.h>
#include <math.h>
/**
#define SCRROW 22      ��ʾ22�� 

#define SCRCOL 79       ��ʾ80�� 
*/
#define SCRROW 34   
#define SCRCOL 132     
#define MAXCOL 1500   /* ����������� */
#define MAXLIN 40960  /* ����������� */
#define TIMEOUT 120    /**  ��ʱʱ��    60 ���� ***/

/* ���̰������� */
#define KBD_EXT_BASE	0x0100 

/* IBM���̰������� */
#define KBD_IBM_BASE	KBD_EXT_BASE		/* ESC������չ������ֵ */

#define KBD_UP			(KBD_IBM_BASE+'A')
#define KBD_DOWN		(KBD_IBM_BASE+'B')
#define KBD_RIGHT		(KBD_IBM_BASE+'C')
#define KBD_LEFT		(KBD_IBM_BASE+'D')

#define KBD_END			(KBD_IBM_BASE+'F')
#define KBD_PGDN		(KBD_IBM_BASE+'G')
#define KBD_HOME		(KBD_IBM_BASE+'H')
#define KBD_PGUP		(KBD_IBM_BASE+'I')

char ta[MAXCOL+1];
char tb[MAXCOL+1];
char tc[MAXCOL+1];
int _MAXCOL = 80 ;
int _MAXLIN = 24 ;
int CurCol = 1;
int CurRow = 0;
int CurRow_bak = 0;
int MovRow = 0;
int MaxLen = 0;
char toward='J';
char s_ward[5]="����";
FILE *fp;
WINDOW *win;

char * DspBuf[SCRROW] ;

int  * pColLen = NULL ;

char errmsg[70];
char filename[81]; 
char FndStr[SCRCOL-20];

            
void set_termstock()
{
	struct	termio	stTermio;

	ioctl( 0, TCGETA, &stTermio );

	stTermio.c_iflag |= IXON | IXOFF;
	stTermio.c_lflag &= ~(ECHO);

	/*ioctl( 0, TCSETAW, &stTermio );
	*/
	ioctl( 0, TCSETAF, &stTermio );

	return;
}


int main(int argc, char *argv[])
{

	win = initscr();
	noecho();
	  
	if ( strlen( argv[1] ) > 1 )
	{
	memset( filename , 0x0 , sizeof( filename ));
	strcpy ( filename , argv[1]  ) ;
	}
	else 
	{
	endwin();
	exit(-1);
	}

	if ( Init ( argc , argv ))
	{
	 endwin();
	 exit(-1) ;
	}


	if ( InzSubR(argc,argv)  )		/* ��ʼ�������� */
	{
	 endwin();
   PrcsErr();
	}

	DispFile(); 			/* ��ʾ�ļ����� */
	
	endwin();  

   PrcsErr();

	return(0);
}

void sigproc ( int sig )
{
 PrcsErr() ;
}
/********************************************************************/
/* DispFile - ��ʾ�ļ�����                                          */
/********************************************************************/
DispFile()
{
	int key;

	signal ( SIGALRM , sigproc ) ;

	do {
		alarm(TIMEOUT); 

		clrbuf();		/* ����Ļ */

		dspbuf();		/* ��ʾ���������� */

		key = prcsinp();
		       
		} while (!key);
	return(0);
}


/********************************************************************/
/*	clrbuf - ����Ļ                                                 */
/********************************************************************/
clrbuf()
{
	char tmpbuf[MAXCOL+1];
	int icol;

	wclear(win); 
	for (icol=0;icol<SCRCOL;icol++)
		tmpbuf[icol] = '-';
	tmpbuf[SCRCOL] = 0x00;
	mvprintw(SCRROW,0,"%s\n",tmpbuf);
	mvprintw((SCRROW+1),0,"%s  Q�˳� Tͷ Bβ /����  %22s",s_ward,basename(filename));
}

/********************************************************************/
/* dspbuf - ��ʾ����������                                          */
/********************************************************************/
dspbuf()
{
	int irow;
	int iChinese=0,i;
	char tmpstr[SCRCOL];
	char space79[SCRCOL];

	memset( space79 , ' ' , SCRCOL-1 ) ;
	space79[SCRCOL - 1]='\0' ;

	for(irow=0;irow<SCRROW;irow++)
	{
		memset(tmpstr,0x00,sizeof(tmpstr));
		strncpy(tmpstr,DspBuf[irow]+CurCol-1,SCRCOL-1) ;

		/* ˫�ֽڴ��� */
		iChinese = 0;
		if (ischinese((unsigned char) tmpstr[0]) )
		{
			for (i=CurCol-1;i>=0;i--)
			{
				if (!ischinese((unsigned char) DspBuf[irow][i])) break;
				else iChinese++;
			}
			if (iChinese%2==0) tmpstr[0]=' ';	
		}

		if ( strcmp(FndStr,"") && strstr(DspBuf[irow],FndStr)) 
			wattrset(win,A_REVERSE); 
		mvprintw(irow,0,"%s",space79);
		mvprintw(irow,0,"%s",tmpstr);
		wattrset(win,A_NORMAL);
	}

	return 0;
}

/********************************************************************/
/*	prcsinp - ���봦��                                              */
/********************************************************************/
prcsinp()
{
	int inp;
	int irow;
	long offset = 0;
	char PrtDest[2] ; /* ��ӡ��ʽ */
	char tmpbuf[MAXCOL+1];

	memset( PrtDest, 0x00, sizeof( PrtDest ) ) ;
	memset( tmpbuf, 0x00, sizeof( tmpbuf ) ) ;
	strcpy( PrtDest, "0" ) ;

	mvprintw(SCRROW,43,"����:��[%d]��[%d] %s", _MAXLIN , _MAXCOL ,basename(filename));
	while(1)	 
	{
	mvprintw((SCRROW+1),0,"%s    ��ǰ��[%d]��[%d]  Q�˳� T/HOMEͷ B/ENDβ PGUP��ҳ/PGDN��ҳ /����  ",s_ward,CurRow + 1 , CurCol );
/*		inp = mvwgetch(win,SCRROW+1,0);  */
		move(SCRROW+1,0);
		inp = scr_wgetch(win);  
		switch(inp)
		{
			case 'q':
			case 'Q': 
				return 1;
			case 'k':    /* ���� */
			case 'K':
				toward = 'K';
				strcpy(s_ward,"����");
				MovVal(1);
				break;
			case 'j':    /* ���� */
			case 'J':
				toward = 'J';
				strcpy(s_ward,"����");
				MovVal(1);
				break;
			case 'l':    /* ���� */
			case 'L':
				toward = 'L';
				strcpy(s_ward,"����");
				MovVal(1);
				break;
			case 'h':    /* ���� */
			case 'H':
				toward = 'H';
				strcpy(s_ward,"����");
				MovVal(1);
				break;
			case 't':    /* �ļ�ͷ */
			case 'T':
			case KBD_HOME:
				rewind(fp);	
				CurRow = 0;
				CurRow_bak = 0;
				filbuf();
				return 0;
			case 'b':    /* �ļ�β */
			case 'B':
			case KBD_END:

				CurRow = _MAXLIN - SCRROW;

				for (irow=0;irow < CurRow ;irow++)
					offset = offset + pColLen[irow];

				if (fseek(fp,offset,SEEK_SET) == -1) rewind(fp);

				filbuf();
				return 0;

			case KBD_LEFT:
				toward = 'H';
				strcpy(s_ward,"����");
				MovVal(1);
				return 0;
			case KBD_RIGHT:
				toward = 'L';
				strcpy(s_ward,"����");
				MovVal(1);
				return 0;
			case KBD_UP:
				toward = 'K';
				strcpy(s_ward,"����");
				MovVal(1);
				return 0;
			case KBD_PGUP:
				toward = 'K';
				strcpy(s_ward,"����");
				MovVal(20);
				return 0;
			case KBD_DOWN:
				toward = 'J';
				strcpy(s_ward,"����");
				MovVal(1);
				return 0;
			case KBD_PGDN:
				toward = 'J';
				strcpy(s_ward,"����");
				MovVal(20);
				return 0;
			case '/':
				memset(FndStr,0x00,sizeof(FndStr));
				memset(tmpbuf,0x00,sizeof(tmpbuf));
				for( irow=0;irow<SCRCOL;irow++) tmpbuf[irow]=' ';
				mvprintw((SCRROW+1),0,"%s",tmpbuf); 
				mvprintw((SCRROW+1),0,"��������ҵ�����: ");
				if (scr_wgets(win,FndStr,SCRCOL-21)==-1) break;  
				if (strcmp(FndStr,"")) 
					if (!FindString("first")) return 0;
				break;
			case '.':
				if (strcmp(FndStr,"")) 
					{
					if(!FindString("no first")) return 0;
					}
				break;
			case 'P':
			case 'p':
				memset(tmpbuf,0x00,sizeof(tmpbuf));
				for( irow=0;irow<SCRCOL;irow++) tmpbuf[irow]=' ';
				mvprintw((SCRROW+1),0,"%s",tmpbuf);
				mvprintw((SCRROW+1),0,"��ӡ��ʽ(0.����  1.������ӡ  2.�ն˴�ӡ): ");
				PrtDest[0]=' ';
				while(PrtDest[0]!='0'&&PrtDest[0]!='1'&&PrtDest[0]!='2')
				{
					PrtDest[ 0 ] = scr_wgetch(win) ;
				}
				
				if (PrtDest[0]=='1')  /* ������ӡ */
				{
					char cmdline[81];
					memset( cmdline, 0x00, sizeof( cmdline ) ) ;
					sprintf(cmdline,"lp %s >/dev/null 2>&1",filename);
					system(cmdline);
				}

				if (PrtDest[0]=='2') /* �ն˴�ӡ */
				{
					char cmdline[81];
					memset( cmdline, 0x00, sizeof( cmdline ) ) ;
					set_termstock();
					system("echo \"\033[5i\"");
					sprintf(cmdline,"cat %s",filename);
					system(cmdline);
					system("echo \"\014\"");
					system("echo \"\033[4i\"");
					set_termstock();
				}

				break;
			default:
				if ((inp >='1') && (inp <='9')) 
				{	MovVal(inp-'0'); return 0; }
		}
	}
}

/********************************************************************/
/* MovVal - �ƶ�����                                               */
/********************************************************************/
MovVal(int mvinp)
{
	int irow;
	long offset = 0;

	switch(toward)
	{
		case 'K':
			MovRow = mvinp;
			if ( CurRow >= 0 ) 
			{
				CurRow -= MovRow   ;
				if ( CurRow < 0 )
				{
				beep();
				CurRow = 0 ;
				}
			}
			for (irow=0;irow< CurRow ;irow++)
				offset = offset + pColLen[ irow ];
			if (fseek(fp, offset,SEEK_SET) == -1) rewind(fp);
			filbuf();
			break;
		case 'J':
			MovRow = mvinp  ;
		    if ( CurRow <= _MAXLIN - SCRROW )
			{
			  CurRow += MovRow ;
		    if ( CurRow  > _MAXLIN - SCRROW )
				{
			   CurRow = _MAXLIN - SCRROW ;
				beep();
				}
			}
			for (irow=0;irow < CurRow;irow++)
				offset = offset + pColLen[irow];
			if (fseek(fp,offset,SEEK_SET) == -1) rewind(fp);
			filbuf();
			break;
		case 'H':
			CurCol -= mvinp;
			if (CurCol <= 0)  
			{
			 CurCol = 1;
			 beep();
			}
			break;
		case 'L':
			CurCol += mvinp;
			if (CurCol  > fabs( _MAXCOL - SCRCOL + 10 ))
			{
			 CurCol -= mvinp;
			 beep();
			}
			break;
	}
  return ;
}

/********************************************************************/
/* InzSubR - ��ʼ��������                                           */
/********************************************************************/
int InzSubR(int Argc, char *Argv[])
{
	char tmpbuf[MAXCOL+1];
	int irow,icol;
	int pLen;

	memset(errmsg,0x00,sizeof(errmsg));
	memset(FndStr,0x00,sizeof(FndStr));

	CurRow = 0 ;
	CurCol = 1 ;
	filbuf();

   return 0 ;
}

/********************************************************************/
/**** read to MAXCOL MAXLINE  add  by yanggang***/
int Init(int Argc, char *Argv[])
{
	char tmpbuf[MAXCOL+1];
	int irow,icol;
	int pLen;
	int maxcol , maxline ;

	memset(errmsg,0x00,sizeof(errmsg));
	memset(FndStr,0x00,sizeof(FndStr));
   

	fp = fopen(filename,"r");
	if (fp == NULL)
	 {  
	   printf( "\n�ļ�%s�򿪳���!\n",filename);	
		return -1 ; 
	 }

maxline = -1  ;
maxcol  =  0 ;


  while ( ! feof ( fp ))
{
	maxline ++ ; 
	memset ( tmpbuf , 0x0 , sizeof ( tmpbuf )) ;

 	fgets ( tmpbuf , MAXCOL , fp ) ;
	irow = strlen ( tmpbuf ) ;

	if ( irow < 0 )
	 return -1 ;

  	if ( irow > maxcol )
	maxcol = irow ;

}
	if ( _MAXCOL < maxcol )
 	_MAXCOL = maxcol  ;
	if ( _MAXLIN < maxline )
	_MAXLIN = maxline ;

	for ( irow = 0 ; irow < SCRROW ; irow ++ )
	{
   		DspBuf[ irow ] = (char  * ) malloc ( _MAXCOL + 1 ) ;
		if ( DspBuf [ irow ] == NULL )
	 		return -1 ;
	}
	pColLen = ( int * )  malloc (  ( _MAXLIN + 1 ) * sizeof ( int ) ) ;
		if ( pColLen == NULL )
		{
		 return -1 ;
		}
	memset ( pColLen , 0x0 ,  (_MAXLIN +1 ) * sizeof (int) ) ;
	
	rewind(fp) ;
	for ( irow = 0 ; irow < _MAXLIN ; irow ++ )
	{
	memset ( tmpbuf , 0x0 , sizeof ( tmpbuf )) ;
 	fgets ( tmpbuf , MAXCOL , fp ) ;
	pColLen[ irow ]  = strlen ( tmpbuf ) ;
	}
	rewind(fp);
return 0 ;	
}

/********************************************************************/
/*  filbuf - ��д������                                             */
/********************************************************************/
filbuf()
{
	char tmpbuf[MAXCOL+1];
	int irow;

	for(irow=0;irow<SCRROW;irow++)
		memset(DspBuf[irow],' ',_MAXCOL); 

	for(irow=0;(!feof(fp) && (irow<SCRROW));irow++)
	{
		memset(tmpbuf,0x00,sizeof(tmpbuf)); 
		fgets(tmpbuf,MAXCOL,fp);	
		strncpy(DspBuf[irow],tmpbuf , _MAXCOL); 
	}

	return 0;
}
/********************************************************************/
/* PrcsErr - ������������                                         */
/********************************************************************/
PrcsErr()
{
int irow ;

fclose(fp);
   
for ( irow = 0 ; irow <  SCRROW ; irow ++ )
	if ( DspBuf[ irow ]  != NULL )
	{
	 free ( DspBuf[ irow ]  ) ;
	}
 free ( pColLen ) ;
	endwin();
	printf("\n%s\n",errmsg);
	exit(1);
}

FindString(char *first)
{
	long offset=0,offset_bak=0;
	long irow;
	char tmpbuf[MAXCOL+1];
	
	/* �������ǰλ�� */

	/* ��һ�β���, �ϻ�һ�� */
	if (!strcmp(first,"first"))
	{
		CurRow_bak = CurRow;
		CurRow -= SCRROW ;
		if ( CurRow < 0 ) ;
			  CurRow = 0 ;

	}

	/* �ӵ�ǰλ�ò��� */

		 CurRow =  CurRow_bak  ;
		offset = 0 ;
		for (irow=0;irow<CurRow;irow++)
			offset = offset + pColLen[irow];

		fseek(fp,offset,SEEK_SET);

	for(;!feof(fp);)
	{
		
		memset(&tmpbuf,0x00,sizeof(tmpbuf)); 
		fgets(tmpbuf,MAXCOL,fp);	
		
		if ( CurRow <= CurRow_bak )
		{
		    CurRow++ ;
			continue ;
		}
		
		if (strstr(tmpbuf,FndStr))
		{
		 CurRow_bak = CurRow ;
		 break;
		}

		  CurRow++ ;
	}

	/* δ�ҵ�ʱ���ز���ǰλ�� */
	if (feof(fp)) 
	{
		offset = 0;
		CurRow = CurRow_bak; 
		if ( CurRow + SCRROW > _MAXLIN )
		     CurRow = _MAXLIN - SCRROW ;
		for (irow=0;irow<CurRow ;irow++)
			offset = offset + pColLen[  irow ];
		fseek(fp,offset,SEEK_SET);
	    beep();
		beep();
		return 1;
	}

		/**CurRow-- ;
		***/

		if ( CurRow < 0 )
		CurRow = 0 ;

		if ( CurRow + SCRROW > _MAXLIN )
		     CurRow = _MAXLIN - SCRROW ;

		CurCol = 1 ;
		offset = 0;
		for (irow=0;irow<CurRow ;irow++)
			offset = offset + pColLen[ irow ];
		fseek(fp,offset,SEEK_SET);
	filbuf();
	return 0;
}

ischinese(unsigned long ch)
{
	if (ch >= 0xa0) return 1;
	else return 0;
}
